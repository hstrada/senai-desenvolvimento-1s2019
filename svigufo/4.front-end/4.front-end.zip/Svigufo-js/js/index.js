import TiposEventos from './TiposEventos.js';

console.log(TiposEventos('Helena'));
// console.log(new TiposEventos('Helena'));