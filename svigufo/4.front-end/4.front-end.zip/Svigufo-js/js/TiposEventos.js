function TiposEventos() {
    console.log('um-tipo-evento');
}

// class TiposEventos {
//     constructor(name) {
//         this.name = name;
//     }
// }

export default TiposEventos